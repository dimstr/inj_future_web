const TelegramBot = require('node-telegram-bot-api');
const fastify = require('fastify')({ logger: true });
const qjson = require("qjson-db");
const looksSame = require('looks-same');
const path = require('path');
const fs = require('fs');
const util = require('util');
const { pipeline } = require('stream');
const pump = util.promisify(pipeline);

const token = '5466049371:AAGPT8a9VuqAsXVRxqnDX_2Rz4rLVAQTp4o';

fastify.register(require('@fastify/static'), {
    root: path.join(__dirname, 'public'),
    prefix: '/public/',
});

fastify.register(require('@fastify/static'), {
    root: path.join(__dirname, 'assets/images'),
    prefix: '/images/',
    decorateReply: false // the reply decorator has been added by the first plugin registration
})

fastify.register(require('@fastify/multipart'));

const bot = new TelegramBot(token, {
    polling: true,
    filepath: false,
});

const main_keyboard = {
    "reply_markup": {
        "resize_keyboard": true,
        "keyboard": [['Открыть трансляцию']]
    }
};

const inline_keyboard = {
    "reply_markup": {
        "resize_keyboard": true,
        "inline_keyboard": [
            [{
                'text': 'Открыть',
                'url': 'https://dimstr.github.io/redirect-to-live/'
            }]
        ]
    }
};

const empty_keyboard = {
    "reply_markup": {
        "remove_keyboard": true
    }
};

function checkauth(chatId) {
    const db = new qjson("./assets/users.json");
    const database = db.JSON();
    var data = database.chats;

    if (data.includes(chatId) == true) {
        return true;
    } else {
        return false;
    }
}

function addchat(chatId) {
    const db = new qjson("./assets/users.json");
    const database = db.JSON();
    var data = database.chats;

    if (data.includes(chatId) == false) {
        data.push(chatId);
        db.set("chats", data);
    }
}


bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;

    if (checkauth(chatId)) {
        bot.sendMessage(chatId, 'Вы уже в списке получения уведомлений', main_keyboard);
    } else {
        bot.sendMessage(chatId, 'Мы не нашли вас в списке пользователей. Введите пароль:', empty_keyboard);
    }
});


bot.on('message', (msg) => {
    const chatId = msg.chat.id;

    if (msg.text.toString().includes("Открыть трансляцию")) {
        if (checkauth(chatId) == true) {
            bot.sendMessage(chatId, 'Для того, чтобы открыть трансляцию нажмите кнопку ниже ', inline_keyboard);
        } else {
            bot.sendMessage(chatId, 'Мы не нашли вас в списке пользователей. Введите пароль:', empty_keyboard);
        }
    } else if (msg.text.toString() == "1412") {

        if (checkauth(chatId) == true) {
            bot.sendMessage(chatId, 'Вы уже в списке получения уведомлений', main_keyboard);
        } else {
            addchat(chatId);

            bot.sendMessage(chatId, 'Верный пароль. Вы добавлены в список', main_keyboard);
        }
    } else if (msg.text == "/start") {
        return;
    } else {
        bot.sendMessage(chatId, '?');
    }
});


fastify.get('/', async function (req, reply) {
    return reply.sendFile('index.html')
})

fastify.get('/live', async function (req, reply) {
    return reply.sendFile('live.html')
})

fastify.post('/upload', async function (req, reply) {
    try {
        const data = await req.file();
        await pump(data.file, fs.createWriteStream('./assets/images/image.jpg'));

        return { 'status': 'success' };
    } catch (err) {
        return { 'status': 'error', 'error': err };
    }
})


fastify.post('/compareimages', async function (req, reply) {
    const image_file = await req.file();
    await pump(image_file.file, fs.createWriteStream('./assets/images/compare2.jpg'));

    const { equal } = await looksSame('./assets/images/compare1.jpg', './assets/images/compare2.jpg', {
        strict: false,
        tolerance: 10,
        antialiasingTolerance: 0,
        ignoreAntialiasing: true,
        ignoreCaret: true
    });

    const notequal = !equal;

    if (notequal == true) {
        const db = new qjson("./assets/users.json");
        const database = db.JSON();
        var data = database.chats;

        const img1 = fs.readFileSync('./assets/images/compare1.jpg');
        const img2 = fs.readFileSync('./assets/images/compare2.jpg');

        var iterations = 0;

        data.forEach(async function (chat_id) {
            bot.sendMediaGroup(chat_id,
                [
                    {
                        type: 'photo',
                        media: img1,
                        caption: 'Обнаружено изменение положения объекта'
                    },
                    {
                        type: 'photo',
                        media: img2,
                    }
                ],
            );
            iterations++;
        });
        if (iterations == data.length) {
            fs.unlinkSync('./assets/images/compare1.jpg');

            fs.renameSync('./assets/images/compare2.jpg', './assets/images/compare1.jpg');
        }
    } else if (notequal == false) {
        return {
            'status': 'OK',
        };

    } else {
        console.log('AAA');
    }

    return {
        'status': 'NOT OK',
        'equal': equal
    };
})


const start = async () => {
    try {
        await fastify.listen({ port: 3000 });
    } catch (err) {
        fastify.log.error(err);
        process.exit(1);
    }
}
start();
